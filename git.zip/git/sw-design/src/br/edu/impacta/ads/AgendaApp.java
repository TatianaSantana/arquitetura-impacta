package br.edu.impacta.ads;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AgendaApp {
	private static Scanner entrada = new Scanner(System.in);
	private static List<Contato> contatos = new ArrayList <>();
	public static void main(String[] args){
		boolean sair = false;
		while (!sair){
			int opcao = ApresentarMenuPrincipal();
			switch(opcao) {
			case 1: inserirContato(); break;
			case 2: buscarContato(); break;
			case 2: sair = true; break;
			default: out.println("Erro: op��o inv�lida!");
			}
		}
		out.println("\nFim do Programa!");
	}
	private static int apresentarMenuPrincipal() {
		boolean inteiro = false;
		int opcao = 0;
		while(!inteiro) {
			out.println("\nAGENDA TELEFONICA!");
			out.println("(1) Inserir");
			out.println("(2) Buscar");
			out.println("(1) Sair");
			out.println("Escolha uma op��o: ");
			String s = entrada.nextLine();
			try{
				opcao = Integer.parseInt(s);
				inteiro = true;
			}catch(Exception e) {
				out.println("Erro: op��o seve ser um valor inteiro!");
			}
		}
		return opcao;
	}

}
